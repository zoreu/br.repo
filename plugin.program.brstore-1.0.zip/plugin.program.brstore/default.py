# -*- coding: utf-8 -*-
import sys
import six
from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import os
import time
import json
import requests
import xml.etree.ElementTree as ET
try:    from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database
import datetime
import re
if six.PY3:
    from urllib.parse import urlparse, unquote, quote_plus, unquote_plus, urlencode #python 3
    from urllib.request import Request, urlopen, URLError  # Python 3
else:    
    from urllib import unquote, quote_plus, unquote_plus, urlencode
    from urllib2 import Request, urlopen, URLError # Python 2
    from urlparse import urlparse


plugin = sys.argv[0]
handle = int(sys.argv[1])
addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
addonid = addon.getAddonInfo('id')
icon = addon.getAddonInfo('icon')
translate = xbmcvfs.translatePath if six.PY3 else xbmc.translatePath
profile = translate(addon.getAddonInfo('profile')) if six.PY3 else translate(addon.getAddonInfo('profile')).decode('utf-8')
home = translate(addon.getAddonInfo('path')) if six.PY3 else translate(addon.getAddonInfo('path')).decode('utf-8')
fanart_default = os.path.join(home, 'fanart.png')
dialog = xbmcgui.Dialog()
addons_py2_url = 'https://bitbucket.org/zoreu123/br.repo/raw/master/addons_leia.txt'
addons_py3_url = 'https://bitbucket.org/zoreu123/br.repo/raw/master/addons_matrix.txt'
store_name = 'BR STORE'

def route(f):
    action_f = f.__name__
    params_dict = {}
    param_string = sys.argv[2]
    if param_string:
        split_commands = param_string[param_string.find('?') + 1:].split('&')
        for command in split_commands:
            if len(command) > 0:
                if "=" in command:
                    split_command = command.split('=')
                    key = split_command[0]
                    value = split_command[1]
                    try:
                        key = unquote_plus(key)
                    except:
                        pass
                    try:
                        value = unquote_plus(value)
                    except:
                        pass
                    params_dict[key] = value
                else:
                    params_dict[command] = ""
    action = params_dict.get('action')
    if action is None and action_f == 'main':
        f()
    elif action == action_f:
        f(params_dict)

def get_kversion():
	full_version_info = xbmc.getInfoLabel('System.BuildVersion')
	baseversion = full_version_info.split(".")
	intbase = int(baseversion[0])
	# if intbase > 16.5:
	# 	log('HIGHER THAN 16.5')
	# if intbase < 16.5:
	# 	log('LOWER THAN 16.5')
	return intbase

def get_url(params):
    if params:
        url = '%s?%s'%(plugin, urlencode(params))
    else:
        url = ''
    return url

def item(params,folder=True):
    u = get_url(params)
    if not u:
        u = ''
    name = params.get("name")
    if name:
        name = name
    else:
        name = 'Unknow'
    iconimage = params.get("iconimage")
    if not iconimage:
        iconimage = icon
    fanart = params.get("fanart")
    if not fanart:
        fanart = fanart_default
    description = params.get("description")
    if not description:
        description = ''           
    liz = xbmcgui.ListItem(name)
    liz.setArt({'fanart': fanart, 'thumb': iconimage, 'icon': "DefaultFolder.png"})
    # if params.get("media"):
    #     liz.setInfo(type="Video", infoLabels={"Title": name, 'mediatype': 'video', "Plot": description})
    # else:
    #     liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    if get_kversion() > 19:
        info = liz.getVideoInfoTag()
        info.setTitle(name)
        info.setPlot(description)
    else:
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    ok = xbmcplugin.addDirectoryItem(handle=handle, url=u, listitem=liz, isFolder=folder)
    return ok


def db_kodi():
    special_dir = 'special://profile/Database'
    directory = translate(special_dir)
    if six.PY3:
        db = os.path.join(directory, 'Addons33.db')
    else:
        db = os.path.join(directory, 'Addons27.db')
    return db

def delete_id(addon_id):
    db = db_kodi()
    try:
        conn = database.connect(db)
        cursor = conn.cursor()
        sql = 'DELETE FROM installed WHERE addonID=?'
        cursor.execute(sql, (addon_id,))
        conn.commit()
        conn.close()
    except:
        pass

def enable_addon(addon_id):
    if get_kversion() >16.5:
        try:
            delete_id(addon_id)
            db = db_kodi()
            now = datetime.datetime.now()
            installDate = now.strftime("%Y-%m-%d %H:%M:%S")
            conn = database.connect(db)
            cursor = conn.cursor()
            sql = 'INSERT INTO installed (addonID,enabled,installDate) VALUES(?,?,?)'
            cursor.execute(sql, (addon_id,1,installDate,))
            conn.commit()
            conn.close()
        except:
            pass

def infoDialog(message, heading=addonname, iconimage='', time=3000, sound=False):
    if iconimage == '':
        iconimage = icon
    elif iconimage == 'INFO':
        iconimage = xbmcgui.NOTIFICATION_INFO
    elif iconimage == 'WARNING':
        iconimage = xbmcgui.NOTIFICATION_WARNING
    elif iconimage == 'ERROR':
        iconimage = xbmcgui.NOTIFICATION_ERROR
    dialog.notification(heading, message, iconimage, time, sound=sound)





def SetView(name):
    if name == 'Wall':
        try:
            xbmc.executebuiltin('Container.SetViewMode(500)')
        except:
            pass
    if name == 'List':
        try:
            xbmc.executebuiltin('Container.SetViewMode(50)')
        except:
            pass
    if name == 'Poster':
        try:
            xbmc.executebuiltin('Container.SetViewMode(51)')
        except:
            pass
    if name == 'Shift':
        try:
            xbmc.executebuiltin('Container.SetViewMode(53)')
        except:
            pass
    if name == 'InfoWall':
        try:
            xbmc.executebuiltin('Container.SetViewMode(54)')
        except:
            pass
    if name == 'WideList':
        try:
            xbmc.executebuiltin('Container.SetViewMode(55)')
        except:
            pass
    if name == 'Fanart':
        try:
            xbmc.executebuiltin('Container.SetViewMode(502)')
        except:
            pass

def addons_list(url):
    try:
        src = requests.get(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36"}).content
        try:
            src = src.decode('utf-8')
        except:
            pass
        padrao = r'addon_name="([^"]+)"\s+addon_image="([^"]+)"\s+addon_xml="([^"]+)"'
        # Procura por todas as correspondências na string
        matches = re.findall(padrao, src)
        # Exibe as correspondências encontradas
        for match in matches:
            addon_name, addon_image, addon_xml = match
            try:
                addon_name = addon_name.encode('utf-8', 'ignore')
            except:
                pass
            item(params={'name': addon_name, 'action': 'install_addon', 'description': '', 'iconimage': addon_image, 'xml': addon_xml},folder=True)
        xbmcplugin.endOfDirectory(handle)
        SetView('WideList')
    except:
        infoDialog('FALHA AO LISTAR OS ADDONS', iconimage='WARNING')


@route
def main():
    if six.PY2:
        addons_list(addons_py2_url)
    else:
        addons_list(addons_py3_url)


@route
def install_addon(params):
    raw_addon_xml = params.get("xml", "")
    addon_name = params.get("name", "")
    if six.PY2:
        q = dialog.yesno(heading=store_name, line1='Deseja instalar %s?'%addon_name, nolabel='NÃO', yeslabel='SIM')
    else:
        q = dialog.yesno(heading=store_name, message='Deseja instalar %s?'%addon_name, nolabel='NÃO', yeslabel='SIM')
    if not q:
        return      
    try:
        xml = requests.get(raw_addon_xml, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36"})
    except:
        xml = ''
    try:
        xml = xml.content.encode('utf-8')
    except:
        xml = xml.content
    dependencie = False
    try:
        root = ET.fromstring(xml)
    except:
        root = False
    if root:
        try:
        
            requires = root.find('requires')

            for addon in requires.findall('import'):
                addon_id = addon.attrib['addon']
                if not addon.get("optional"):
                    try:
                        xbmc.executebuiltin('InstallAddon(%s)'%addon_id)
                        xbmc.executebuiltin('SendClick(11)')
                    except:
                        pass
            dependencie = True
        except:
            pass
    if dependencie and root:
        addon_id = root.attrib['id']
        addon_version = root.attrib['version']
        if addon_id == 'plugin.video.elementum' or addon_id == 'script.elementum.burst':
            url_base = 'https://github.com/elgatito/'+addon_id+'/releases/download/v'+addon_version+'/'+addon_id+'-'+addon_version+'.zip'
        else:
            parsed_url = urlparse(raw_addon_xml)
            path = parsed_url.path
            directory_url = os.path.dirname(path)
            url_base = '%s://%s/%s/%s-%s.zip'%(parsed_url.scheme,parsed_url.netloc,directory_url[1:],addon_id,addon_version)
        enable_install = False
        try:
            r = requests.head(url_base, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36"})
            if r.status_code == 200 or r.status_code == 302:
                enable_install = True
        except:
            enable_install = False         
        if enable_install:
            special_dir = 'special://home/addons/'+addon_id
            special_packages = 'special://home/addons/packages'
            addons_dir = 'special://home/addons/'
            dest_dir = translate(addons_dir)
            directory = translate(special_dir)
            packages = translate(special_packages)
            try:
                import downloader, extract
                import ntpath
                filename = ntpath.basename(url_base)
                dest=os.path.join(packages, filename)
                dp = xbmcgui.DialogProgress()
                if six.PY3:
                    dp.create('Baixando '+addon_id+'...','Aguarde...')
                else:
                    dp.create('Baixando '+addon_id+'...','Aguarde...', '', '')
                downloader.download(url_base,addon_id,dest,dp=dp)
                zip_file = dest
                extract_folder = dest_dir
                if six.PY3:
                    dp.create('Extraindo '+addon_id+'...','Aguarde...')
                else:
                    dp.create('Extraindo '+addon_id+'...','Aguarde...', '', '')
                dp.update(0)
                extract.all(zip_file,extract_folder, dp=dp)
                try:
                    os.remove(zip_file)
                except:
                    pass
                time.sleep(3)
                if six.PY2:
                    xbmc.executebuiltin("XBMC.UpdateLocalAddons")
                else:
                    xbmc.executebuiltin("UpdateLocalAddons")              
                enable_addon(addon_id)
                time.sleep(3)
                if six.PY2:
                    xbmc.executebuiltin("XBMC.UpdateAddonRepos")
                else:
                    xbmc.executebuiltin("UpdateAddonRepos")
                try:
                    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":true}}'%addon_id)
                except:
                    pass
                infoDialog('%s instalado com sucesso!'%addon_name, iconimage='INFO')
                if addon_id == 'plugin.video.elementum' or addon_id == 'plugin.video.thethunder':
                    dialog.ok(store_name, 'FECHE O KODI E ABRA NOVAMENTE PARA CARREGAR AS TRADUÇÕES')
            except:
                infoDialog('Error', iconimage='WARNING')

        else:
            infoDialog('Url desatualizada', iconimage='WARNING')
    else:
        infoDialog('Falha nas depencencias', iconimage='WARNING')


